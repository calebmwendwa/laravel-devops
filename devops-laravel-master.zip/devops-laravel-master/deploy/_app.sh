#!/bin/bash

# Global variables that are used by the scripts

# Deployment user
username=UNAME
password=PWORD
db_password=DB_PWORD

# Deployment
app_type=APP_TYPE
app_port=PORT
repo=REPO_URL

# Public SSH Key for Remote Access As Deployment User
public_ssh_key=PUB_SSH_KEY
