#!/bin/bash

# Install certbot
sudo apt install -y certbot python3-certbot-nginx
