#!/bin/bash

# Install Memcached
sudo apt-get install -y memcached

