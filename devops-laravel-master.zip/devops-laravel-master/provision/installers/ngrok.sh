#!/bin/bash

# Install ngrok
sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip
sudo unzip -o ngrok-stable-linux-amd64.zip -d /usr/local/bin
sudo rm -rf ngrok-stable-linux-amd64.zip