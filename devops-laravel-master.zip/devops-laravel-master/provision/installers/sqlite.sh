#!/bin/bash

# Install SQLite
sudo apt install -y sqlite3 libsqlite3-dev